function formatAccessibilitySnapshot(rawSnapshot, maxLines = 200) {
  const nodes = rawSnapshot.nodes || [];
  const nodeMap = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    nodeMap.set(node.nodeId, { ...node, children: [] });
  }
  let rootNode = null;
  for (const node of nodeMap.values()) {
    if (node.parentId) {
      const parent = nodeMap.get(node.parentId);
      if (parent) {
        parent.children.push(node);
      }
    } else {
      rootNode = node;
    }
  }
  if (!rootNode) {
    return {
      nodes: [],
      totalLines: 0,
      truncated: false
    };
  }
  collapseTree(rootNode);
  const totalLines = { count: 0 };
  const formatted = formatTree([rootNode], 0, totalLines, maxLines);
  return {
    nodes: formatted,
    totalLines: totalLines.count,
    truncated: totalLines.count >= maxLines,
    truncationMessage: totalLines.count >= maxLines ? `Snapshot truncated at ${maxLines} lines to save bandwidth` : void 0
  };
}
function collapseTree(node) {
  var _a, _b;
  if (node.children && node.children.length > 0) {
    for (const child of node.children) {
      collapseTree(child);
    }
  }
  const role = ((_a = node.role) == null ? void 0 : _a.value) || "unknown";
  const name = ((_b = node.name) == null ? void 0 : _b.value) || "";
  const isUseless = (role === "none" || role === "generic" || role === "unknown") && !name;
  if (isUseless && node.children && node.children.length === 1) {
    const child = node.children[0];
    node.role = child.role;
    node.name = child.name;
    node.value = child.value;
    node.children = child.children || [];
    collapseTree(node);
  }
}
function generateSelectorHint(role, name, value) {
  const interactiveRoles = ["textbox", "combobox", "searchbox", "spinbutton"];
  if (!interactiveRoles.includes(role)) {
    return void 0;
  }
  return 'CSS: #id, input[type="..."], or input[name="..."]';
}
function formatTree(nodes, depth, totalLines, maxLines) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  if (!nodes || nodes.length === 0 || totalLines.count >= maxLines) {
    return [];
  }
  const nodesToProcess = depth === 0 ? nodes.slice(0, 100) : nodes;
  const result = [];
  const groups = groupByRole(nodesToProcess);
  for (const group of groups) {
    if (totalLines.count >= maxLines) break;
    if (group.nodes.length === 1) {
      const node = group.nodes[0];
      const name = ((_b = (_a = node.name) == null ? void 0 : _a.value) == null ? void 0 : _b.toString()) || "";
      const value = ((_d = (_c = node.value) == null ? void 0 : _c.value) == null ? void 0 : _d.toString()) || "";
      const selectorHint = generateSelectorHint(group.role);
      const formatted = {
        role: group.role,
        name: name || void 0,
        value: value || void 0,
        selectorHint: selectorHint || void 0
      };
      totalLines.count++;
      if (node.children && node.children.length > 0 && totalLines.count < maxLines) {
        formatted.children = formatTree(node.children, depth + 1, totalLines, maxLines);
      }
      result.push(formatted);
    } else {
      const first = group.nodes.slice(0, 2);
      const last = group.nodes.slice(-1);
      const skippedCount = group.nodes.length - 3;
      for (const node of first) {
        if (totalLines.count >= maxLines) break;
        const name = ((_f = (_e = node.name) == null ? void 0 : _e.value) == null ? void 0 : _f.toString()) || "";
        const value = ((_h = (_g = node.value) == null ? void 0 : _g.value) == null ? void 0 : _h.toString()) || "";
        const selectorHint = generateSelectorHint(group.role);
        const formatted = {
          role: group.role,
          name: name || void 0,
          value: value || void 0,
          selectorHint: selectorHint || void 0
        };
        totalLines.count++;
        if (node.children && node.children.length > 0 && totalLines.count < maxLines) {
          formatted.children = formatTree(node.children, depth + 1, totalLines, maxLines);
        }
        result.push(formatted);
      }
      if (totalLines.count < maxLines && skippedCount >= 10) {
        result.push({
          role: group.role,
          isGroupSummary: true,
          groupCount: skippedCount
        });
        totalLines.count++;
      }
      for (const node of last) {
        if (totalLines.count >= maxLines) break;
        const name = ((_j = (_i = node.name) == null ? void 0 : _i.value) == null ? void 0 : _j.toString()) || "";
        const value = ((_l = (_k = node.value) == null ? void 0 : _k.value) == null ? void 0 : _l.toString()) || "";
        const selectorHint = generateSelectorHint(group.role);
        const formatted = {
          role: group.role,
          name: name || void 0,
          value: value || void 0,
          selectorHint: selectorHint || void 0
        };
        totalLines.count++;
        if (node.children && node.children.length > 0 && totalLines.count < maxLines) {
          formatted.children = formatTree(node.children, depth + 1, totalLines, maxLines);
        }
        result.push(formatted);
      }
    }
  }
  return result;
}
function groupByRole(nodes) {
  var _a, _b;
  if (nodes.length === 0) return [];
  const groups = [];
  let currentGroup = null;
  for (const node of nodes) {
    const role = ((_b = (_a = node.role) == null ? void 0 : _a.value) == null ? void 0 : _b.toString()) || "unknown";
    if (!currentGroup || currentGroup.role !== role) {
      currentGroup = { role, nodes: [node] };
      groups.push(currentGroup);
    } else {
      currentGroup.nodes.push(node);
    }
  }
  return groups;
}
export {
  formatAccessibilitySnapshot
};
